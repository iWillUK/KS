//
//  Copyright © 2011-2020 PSPDFKit GmbH. All rights reserved.
//
//  THIS SOURCE CODE AND ANY ACCOMPANYING DOCUMENTATION ARE PROTECTED BY INTERNATIONAL COPYRIGHT LAW
//  AND MAY NOT BE RESOLD OR REDISTRIBUTED. USAGE IS BOUND TO THE PSPDFKIT LICENSE AGREEMENT.
//  UNAUTHORIZED REPRODUCTION OR DISTRIBUTION IS SUBJECT TO CIVIL AND CRIMINAL PENALTIES.
//  This notice may not be removed from this file.
//

#import <PSPDFKit/PSPDFEnvironment.h>
#import <PSPDFKit/PSPDFUndoSupport.h>

NS_ASSUME_NONNULL_BEGIN

/**
 Sent once we have new undo operations available.

 @note Always sent on the main thread.
 */
PSPDF_EXPORT NSNotificationName const PSPDFUndoControllerAddedUndoActionNotification;

/**
 Sent once we have available undo actions have been changed/removed.

 @note Always sent on the main thread.
 */
PSPDF_EXPORT NSNotificationName const PSPDFUndoControllerRemovedUndoActionNotification;

/**
 This is a custom undo manager that can coalesce similar changes within the same group.
 This class is thread safe. 
 
 PSPDFKit creates instances of this class internally and makes them available on various objects.
 You should not create new instances of this class yourself.
 
 @note Only use a perform/lock block if you're not in any other lock controlled by PSPDFKit.
 */
PSPDF_CLASS_SUBCLASSING_RESTRICTED_SWIFT(UndoController)
@interface PSPDFUndoController : NSObject

/// Returns YES if the undo controller is currently either undoing or redoing.
@property (nonatomic, getter=isWorking, readonly) BOOL working;

/// Returns YES if the undo controller is currently undoing.
@property (nonatomic, getter=isUndoing, readonly) BOOL undoing;

/// Returns YES if the undo controller is currently redoing.
@property (nonatomic, getter=isRedoing, readonly) BOOL redoing;

/**
 Returns YES if undoable operations have been recorded.

 @note This is a calculated property and does not support KVO.
 Listen to NSUndoManagerDid* and PSPDFUndoController* notification events instead.
 */
@property (atomic, readonly) BOOL canUndo;

/**
 Returns YES if recordable operations have been recorded.

 @note This is a calculated property and does not support KVO.
 Listen to NSUndoManagerDid* and PSPDFUndoController* notification events instead.
 */
@property (atomic, readonly) BOOL canRedo;

/**
 Performs an undo operation.

 @note If undo is not possible, this is a NOP.
 */
- (void)undo;

/**
 Performs a redo operation.

 @note If redo is not possible, this is a NOP.
 */
- (void)redo;

/// Helper that will infer a good name for `changedProperty` of `object`.
- (void)endUndoGroupingWithProperty:(NSString *)changedProperty ofObject:(nullable id)object;

/// Removes all recorded actions.
- (void)removeAllActions;

/**
 Removes all recorded actions with the provided target.
 Implement `performUndoAction:` from `PSPDFUndoSupport` to add support for conditional
 removal of `PSPDFUndoSupport` tracked (observed) changes.
 */
- (void)removeAllActionsWithTarget:(id)target;

/// Register an object.
- (void)registerObjectForUndo:(NSObject<PSPDFUndoSupport> *)object;

/// Unregister an object.
- (void)unregisterObjectForUndo:(NSObject<PSPDFUndoSupport> *)object;

/**
 Support for regular invocation based undo.
 Perform the call you would normally invoke after [undoManager prepareWithInvocationTarget:target]
 on the proxy passed into the block.
 */
- (void)prepareWithInvocationTarget:(id)target block:(void (^)(id proxy))block;

/**
 Provides access to the underlying `NSUndoManager`. You are strongly encouraged to not use this
 property since it is not thread safe and `PSPDFUndoController` manages the state of this undo manager.
 However, since `UIResponders` can provide an undo manager, this property is exposed.
 */
@property (nonatomic, readonly) NSUndoManager *undoManager;

/// Specifies the time interval that is used for `PSPDFUndoCoalescingTimed`. Defaults to 0.5 seconds.
@property (nonatomic) NSTimeInterval timedCoalescingInterval;

/// Specifies the levels of undo we allow. Defaults to 100. More means higher memory usage.
@property (nonatomic) NSUInteger levelsOfUndo;

/**
 Required for conditional undo removal support using `removeAllActionsWithTarget:`.

 @see PSPDFUndoSupport
 */
- (void)performUndoAction:(PSPDFUndoAction *)action;

@end

@interface PSPDFUndoController (TimeCoalescingSupport)

/**
 Commits all incomplete undo actions. This method is automatically called before undoing or redoing,
 so there's usually no need to call this method directly.
 */
- (void)commitIncompleteUndoActions;

/// Indicates that there are still incomplete undo actions because of a coalescing policy.
@property (nonatomic, readonly) BOOL hasIncompleteUndoActions;

/// Returns the name of the most recent incomplete action or nil.
@property (nonatomic, readonly, nullable) NSString *incompleteUndoActionName;

@end

/// Performs a block and groups all observed changes into one event, if the undo controller is available.
PSPDF_EXPORT void PSPDFPerformBlockAsGroup(PSPDFUndoController *_Nullable undoController, NS_NOESCAPE dispatch_block_t block, NSString *_Nullable name) NS_SWIFT_NAME(UndoController.performAsGroup(undoController:closure:name:));

/// Performs a block and ignores all observed changes, if the undo controller is available.
PSPDF_EXPORT void PSPDFPerformBlockWithoutUndo(PSPDFUndoController *_Nullable undoController, NS_NOESCAPE dispatch_block_t block) NS_SWIFT_NAME(UndoController.performWithoutUndo(undoController:closure:));

NS_ASSUME_NONNULL_END
