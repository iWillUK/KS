//
//  Copyright © 2019-2020 PSPDFKit GmbH. All rights reserved.
//
//  THIS SOURCE CODE AND ANY ACCOMPANYING DOCUMENTATION ARE PROTECTED BY INTERNATIONAL COPYRIGHT LAW
//  AND MAY NOT BE RESOLD OR REDISTRIBUTED. USAGE IS BOUND TO THE PSPDFKIT LICENSE AGREEMENT.
//  UNAUTHORIZED REPRODUCTION OR DISTRIBUTION IS SUBJECT TO CIVIL AND CRIMINAL PENALTIES.
//  This notice may not be removed from this file.
//

#import <PSPDFKit/PSPDFModelObject.h>
#import <PSPDFKit/PSPDFMacros.h>

NS_ASSUME_NONNULL_BEGIN

@class PSPDFRenderOptions, PSPDFAnnotation;

/**
 A block passed to PSPDFKit to render additional content or graphics on a page. Set it on `-[PSPDFRenderOptions drawBlock]`.

 @param context The graphics context that should be drawn into.
 @param pageIndex The index of the page being drawn.
 @param pageRect A rectangle the size of the page being drawn, with zero origin.
 @param options The `PSPDFRenderOptions` object that this block was attached to. For reference purposes only.
 */
typedef void (^PSPDFRenderDrawBlock)(CGContextRef context, PSPDFPageIndex pageIndex, CGRect pageRect, PSPDFRenderOptions *options);

typedef NS_OPTIONS(NSUInteger, PSPDFRenderFilter) {
    /// If set, a grayscale filter will be applied.
    PSPDFRenderFilterGrayscale = 1 << 0,

    /// If set and `invertRenderColor` is `YES`, the inverted mode (a.k.a. night mode) will be rendered color correct.
    PSPDFRenderFilterColorCorrectInverted = 1 << 1,

    /// If set, a sepia filter will be applied.
    PSPDFRenderFilterSepia = 1 << 2
} PSPDF_ENUM_SWIFT(RenderFilter);

// No support for macOS yet (CIFilter behaves differently there)
#define PSPDF_SUPPORTS_CIFILTER (TARGET_OS_IOS || TARGET_OS_TV)

/**
 Defines the options to apply when rendering PDF pages, such as color inversion, filters,
 colors and annotation behavior.
 */
PSPDF_CLASS_SWIFT(RenderOptions)
@interface PSPDFRenderOptions : PSPDFModel <NSSecureCoding>

/// Changes the rendering to preserve the aspect ratio of the image. Defaults to `NO`.
@property (nonatomic) BOOL preserveAspectRatio;

/// Controls whether the image is forced to render with a scale of 1.0. Defaults to `NO`.
@property (nonatomic) BOOL ignoreDisplaySettings;

/**
 A color that is multiplied with the page content to color the pages. Defaults to `UIColor.clearColor`.
 If the page content draws a white square, the resulting color of that square will be `pageColor`.
 To set a background without tinting the page content, use `backgroundFill` instead.
 */
@property (nonatomic) UIColor *pageColor;

/// Inverts the rendering output. Defaults to `NO`.
@property (nonatomic) BOOL invertRenderColor;

/// Filters to be applied. Filters will increase rendering time. Defaults to no filters.
@property (nonatomic) PSPDFRenderFilter filters;

/// Set custom interpolation quality. Defaults to `kCGInterpolationHigh`.
@property (nonatomic) CGInterpolationQuality interpolationQuality;

/// Set to `YES` to NOT draw page content. Defaults to NO. (Use to just draw an annotation).
@property (nonatomic) BOOL skipPageContent;

/// Set to `YES` to render annotations that have `isOverlay = YES` set. Defaults to `NO`.
@property (nonatomic) BOOL overlayAnnotations;

/// Skip rendering of any annotations that are in this array.
@property (nonatomic, nullable) NSArray<PSPDFAnnotation *> *skipAnnotationArray;

/// If `YES`, will draw outside of page area. Defaults to `NO`.
@property (nonatomic) BOOL ignorePageClip;

/// Enables/Disables antialiasing. Defaults to `YES`.
@property (nonatomic) BOOL allowAntialiasing;

/**
 The page base color. Page content is drawn on top of this fill. Defaults to `UIColor.whiteColor`.
 If the page content draws a white square, the resulting color of that square will be white regardless of the `backgroundFill`.
 To tint the page content too, use `pageColor` instead.
 */
@property (nonatomic) UIColor *backgroundFill;

/**
 Whether native text rendering via Core Graphics should be used. Defaults to `YES`.

 @note Native text rendering usually yields better results but is slower.
 */
@property (nonatomic) BOOL renderTextUsingCoreGraphics;

/**
 Sets the interactive fill color, which will override the fill color for all newly
 rendered form elements that are editable.

 The interactive fill color is used if a form element is editable by the user to
 indicate that the user can interact with this form element.

 If this value is set, it will always be used if the element is editable and the
 `fillColor` specified by the PDF is ignored. Remove this key to use the fill color
 specified in the PDF.

 Defaults to a non-nil, light blue color.
 */
@property (nonatomic, nullable) UIColor *interactiveFormFillColor;

/// Allows custom content rendering after the PDF.
@property (nonatomic, nullable) PSPDFRenderDrawBlock drawBlock;

/// Controls if the "Sign here" overlay should be shown on unsigned signature fields. Defaults to `YES`.
@property (nonatomic) BOOL drawSignHereOverlay;

/**
 Controls if redaction annotations should be drawn in their redacted state, to preview the appearance of how
 they would look if applied. By default redactions are rendered in their marked state.

 Defaults to `NO`.
 */
@property (nonatomic) BOOL drawRedactionsAsRedacted;

#if PSPDF_SUPPORTS_CIFILTER
/// `CIFilter` that are applied to the rendered image before it is returned from the render pipeline.
@property (nonatomic, nullable) NSArray<CIFilter *> *additionalCIFilters;
#endif

#pragma mark Annotation Drawing Options

/// Whether the annotations are drawn flattened when processing a document. Defaults to `NO`.
@property (nonatomic) BOOL drawFlattened;

/// Set to `YES` to specify that the annotation is being drawn for printing. Defaults to `NO`.
@property (nonatomic) BOOL drawForPrinting;

/// If the annotation should be rendered centered within it's own context. Defaults to `NO`.
@property (nonatomic) BOOL centered;

/// The margin that should be applied to the drawing annotation. Defaults to (0,0,0,0).
@property (nonatomic) UIEdgeInsets margin;

/// Whether the annotation's appearance stream should be rendered. Defaults to `NO`.
@property (nonatomic) BOOL drawAppearanceStream;

#pragma mark Lifecycle

PSPDF_INIT_WITH_CODER_UNAVAILABLE

- (nullable instancetype)initWithDictionary:(nullable NSDictionary<NSString *, id> *)dictionaryValue error:(NSError * __autoreleasing _Nullable *)error PSPDF_NOT_DESIGNATED_INITIALIZER_ATTRIBUTE;

@end

NS_ASSUME_NONNULL_END
